public interface HasKey<Key>
{
	Key getKey();
}
